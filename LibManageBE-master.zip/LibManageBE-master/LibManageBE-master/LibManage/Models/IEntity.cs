﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibManage.Models
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
